-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2022 at 04:22 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `code_phonestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE `gifts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `series` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screen` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memory` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_system` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpu` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `camera` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sim` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int(10) UNSIGNED DEFAULT NULL,
  `stock` int(10) UNSIGNED DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `flag` tinyint(4) DEFAULT 4 COMMENT '1: New 2:Best Seller 3: Hot Item 4:None',
  `total_reviews` int(10) UNSIGNED DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gifts`
--

INSERT INTO `gifts` (`id`, `slug`, `series`, `screen`, `memory`, `operation_system`, `cpu`, `camera`, `sim`, `battery`, `points`, `stock`, `rating`, `flag`, `total_reviews`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'samsung-galaxy-s9-midnight-black-464-gb', 'Samsung Galaxy S9-Midnight Black 4/64 GB', '6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired', 200000, 0, 5, 4, 50, NULL, NULL, NULL, '2022-01-29 15:44:52', NULL),
(2, 'samsung-galaxy-m52-5g', 'Samsung Galaxy S9-Midnight Black 4/64 GB', '6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired', 350000, 10, 5, 4, 182, NULL, NULL, NULL, '2022-01-29 15:53:51', NULL),
(3, 'xiaomi-redmi-note-10', 'Xiaomi Redmi Note 10', '6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired', 225000, 10, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
(4, 'samsung-galaxy-a52-5g', 'Samsung Galaxy A52 5G', '6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired', 150000, 7, NULL, 2, 0, NULL, NULL, NULL, NULL, NULL),
(5, 'samsung-galaxy-a52s-5g', 'Samsung Galaxy A52s 5G', '6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired', 450000, 4, NULL, 3, 0, NULL, NULL, NULL, NULL, NULL),
(7, 'xiaomi-redmi-note-10', 'xiaomi redmi note 10', 'Ukuran layar: 6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9', 'RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB', 'Android 8.0 (Oreo)', 'Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor', 'Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR', 'Dual SIM (Nano-SIM)', 'Non-removable Li-Ion 3500 mAh , Fast Charging on wired and wireless', 15000, 40, NULL, 4, 20, NULL, NULL, '2022-01-29 15:59:41', '2022-01-29 15:59:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(89, '2014_10_12_000000_create_users_table', 1),
(90, '2014_10_12_100000_create_password_resets_table', 1),
(91, '2019_08_19_000000_create_failed_jobs_table', 1),
(92, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(93, '2022_01_26_145654_create_gifts_table', 1),
(94, '2022_01_27_062552_add_api_token_to_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'auth_token', '6eee54449ea44a006fc9e30371e4490d0623156ef96cfe2f8781ae68f7302889', '[\"*\"]', '2022-01-29 15:59:40', '2022-01-29 15:57:04', '2022-01-29 15:59:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fullname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int(10) UNSIGNED DEFAULT NULL COMMENT 'Poin user untuk redeem item',
  `roles` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '1: Admin 2:Operator 3:Customer',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `api_token` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `username`, `password`, `points`, `roles`, `remember_token`, `created_at`, `updated_at`, `api_token`) VALUES
(1, 'M Salman Agustian', 'salmanagustian', '$2y$10$bEkpYxr6YJYvszoPqV/sqedIEi6Xu.h2m05n78E8i8QCH29QNdf4y', 0, 'admin', NULL, '2022-01-29 12:37:23', NULL, NULL),
(2, 'Jarrell Jacobi', 'christiansen.ethel', '$2y$10$v6XSZFzZC8jiGfWZHZ9bCO0p5OX64vUP7TFFoIOsZ2NCxXfTkS5oK', 271009, 'customer', NULL, '2022-01-29 12:37:24', NULL, NULL),
(3, 'Carey Wolff II', 'stiedemann.mara', '$2y$10$PGmQ7cUD0i3jxE0rCd2Mzei1aZfMD0/UaptzynZRZStC7lw1i49ye', 361516, 'customer', NULL, '2022-01-29 12:37:24', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_api_token_unique` (`api_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
